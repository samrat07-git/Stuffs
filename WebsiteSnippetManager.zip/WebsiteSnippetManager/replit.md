# Samrat Singh Portfolio Website

## Overview

This is a static portfolio website for Samrat Singh, a Computer Science student and aspiring developer. The project is built using vanilla HTML, CSS, and JavaScript with a focus on clean design, accessibility, and performance. The website serves as a digital resume and portfolio showcase, hosted using Python's built-in HTTP server.

## System Architecture

### Frontend Architecture
- **Static Site**: Pure HTML5, CSS3, and vanilla JavaScript
- **Responsive Design**: Mobile-first approach with CSS Grid and Flexbox
- **Progressive Enhancement**: Core functionality works without JavaScript
- **Semantic HTML**: Proper use of HTML5 semantic elements for accessibility

### Hosting Strategy
- **Development Server**: Python's built-in HTTP server (`python -m http.server`)
- **Static File Serving**: All assets served directly from the file system
- **Port Configuration**: Runs on port 5000 by default

## Key Components

### 1. **Main Portfolio Page (index.html)**
- Header with contact information and social links
- Navigation system for smooth scrolling
- Sections for skills, projects, and experience
- SEO-optimized with proper meta tags and Open Graph data

### 2. **Styling System (styles/style.css)**
- CSS Custom Properties for consistent theming
- Modern CSS techniques (Grid, Flexbox, Custom Properties)
- Accessibility-focused design with skip links
- Responsive breakpoints for mobile, tablet, and desktop

### 3. **Interactive Features (scripts/main.js)**
- Smooth scrolling navigation
- Active section highlighting
- Keyboard navigation support
- Intersection Observer for performance
- Skill and project interaction animations

### 4. **Asset Management**
- Resume PDF download functionality
- Font Awesome icons for social media links
- Google Fonts integration (Inter font family)
- Placeholder resume PDF file

## Data Flow

1. **Static Asset Loading**: Browser requests HTML, CSS, and JS files from Python server
2. **Font Loading**: External fonts loaded from Google Fonts CDN
3. **Icon Loading**: Font Awesome icons loaded from CDN
4. **Navigation Interaction**: JavaScript handles smooth scrolling and active states
5. **Resume Download**: Direct file serving of PDF assets

## External Dependencies

### CDN Resources
- **Google Fonts**: Inter font family for typography
- **Font Awesome**: Icons for social media and UI elements

### Development Tools
- **Python HTTP Server**: Built-in development server
- **Replit Environment**: Node.js 20 and Python 3.11 modules

## Deployment Strategy

### Local Development
- Python HTTP server serves static files on port 5000
- Hot reloading through manual refresh
- No build process required

### Production Considerations
- Can be deployed to any static hosting service (Netlify, Vercel, GitHub Pages)
- No server-side processing required
- All assets are self-contained except CDN dependencies

### Performance Optimizations
- Minimal external dependencies
- Efficient CSS using custom properties
- Vanilla JavaScript for minimal bundle size
- Semantic HTML for better SEO and accessibility

## Changelog
- June 16, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.