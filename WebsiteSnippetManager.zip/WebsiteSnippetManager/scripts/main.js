/**
 * Main JavaScript file for Samrat Singh's Portfolio Website
 * Handles smooth scrolling, interactive effects, and accessibility features
 */

(function() {
    'use strict';

    // DOM elements
    const navLinks = document.querySelectorAll('nav a[href^="#"]');
    const sections = document.querySelectorAll('section[id]');
    const skillItems = document.querySelectorAll('.skill-item');
    const projectItems = document.querySelectorAll('.project');
    const videoItems = document.querySelectorAll('.video-item');

    /**
     * Initialize the application
     */
    function init() {
        setupSmoothScrolling();
        setupActiveNavigation();
        setupSkillItemInteractions();
        setupProjectInteractions();
        setupVideoInteractions();
        setupKeyboardNavigation();
        setupIntersectionObserver();
        console.log('Portfolio website initialized successfully');
    }

    /**
     * Setup smooth scrolling for navigation links
     */
    function setupSmoothScrolling() {
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href').substring(1);
                const targetSection = document.getElementById(targetId);
                
                if (targetSection) {
                    const headerOffset = 100; // Account for sticky navigation
                    const elementPosition = targetSection.offsetTop;
                    const offsetPosition = elementPosition - headerOffset;

                    window.scrollTo({
                        top: offsetPosition,
                        behavior: 'smooth'
                    });

                    // Update URL without triggering scroll
                    history.replaceState(null, null, `#${targetId}`);
                    
                    // Announce to screen readers
                    announceToScreenReader(`Navigated to ${targetSection.querySelector('h2').textContent} section`);
                }
            });
        });
    }

    /**
     * Setup active navigation highlighting
     */
    function setupActiveNavigation() {
        function updateActiveNav() {
            let currentSection = '';
            const scrollPosition = window.scrollY + 150;

            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                
                if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                    currentSection = section.getAttribute('id');
                }
            });

            // Update active nav link
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${currentSection}`) {
                    link.classList.add('active');
                }
            });
        }

        // Throttled scroll listener for performance
        let scrollTimeout;
        window.addEventListener('scroll', () => {
            if (scrollTimeout) {
                clearTimeout(scrollTimeout);
            }
            scrollTimeout = setTimeout(updateActiveNav, 10);
        });

        // Initial call
        updateActiveNav();
    }

    /**
     * Setup skill item hover interactions
     */
    function setupSkillItemInteractions() {
        skillItems.forEach(item => {
            // Add ripple effect on click
            item.addEventListener('click', function(e) {
                createRippleEffect(e, this);
            });

            // Enhanced accessibility
            item.setAttribute('tabindex', '0');
            item.setAttribute('role', 'button');
            
            item.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    createRippleEffect(e, this);
                }
            });
        });
    }

    /**
     * Setup project card interactions
     */
    function setupProjectInteractions() {
        projectItems.forEach(project => {
            const projectLinks = project.querySelectorAll('.project-link');
            
            // Add hover effects
            project.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px)';
            });

            project.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });

            // Ensure project links are accessible
            projectLinks.forEach(link => {
                link.addEventListener('focus', function() {
                    project.style.transform = 'translateY(-5px)';
                });

                link.addEventListener('blur', function() {
                    project.style.transform = 'translateY(0)';
                });
            });
        });
    }

    /**
     * Setup video item interactions
     */
    function setupVideoInteractions() {
        videoItems.forEach(video => {
            const playButton = video.querySelector('.play-button');
            
            // Add hover effects
            video.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px)';
                playButton.style.transform = 'translate(-50%, -50%) scale(1.1)';
            });

            video.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
                playButton.style.transform = 'translate(-50%, -50%) scale(1)';
            });

            // Add click functionality
            video.addEventListener('click', function() {
                const videoTitle = this.querySelector('h3').textContent;
                announceToScreenReader(`Opening video: ${videoTitle}`);
                
                // Add ripple effect
                createRippleEffect(event, this);
                
                // Simulate video opening (in real implementation, this would open actual video)
                console.log(`Opening video: ${videoTitle}`);
            });

            // Ensure accessibility
            video.setAttribute('tabindex', '0');
            video.setAttribute('role', 'button');
            video.setAttribute('aria-label', `Play video: ${video.querySelector('h3').textContent}`);
            
            video.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.click();
                }
            });
        });
    }

    /**
     * Setup keyboard navigation improvements
     */
    function setupKeyboardNavigation() {
        // Add keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Alt + number keys for quick navigation
            if (e.altKey && !e.ctrlKey && !e.shiftKey) {
                const keyNum = parseInt(e.key);
                if (keyNum >= 1 && keyNum <= navLinks.length) {
                    e.preventDefault();
                    navLinks[keyNum - 1].click();
                }
            }

            // Escape key to return to top
            if (e.key === 'Escape') {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });

        // Improve focus visibility
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                document.body.classList.add('keyboard-navigation');
            }
        });

        document.addEventListener('mousedown', function() {
            document.body.classList.remove('keyboard-navigation');
        });
    }

    /**
     * Setup Intersection Observer for animations
     */
    function setupIntersectionObserver() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);

        // Observe sections, project cards, and video items
        sections.forEach(section => observer.observe(section));
        projectItems.forEach(project => observer.observe(project));
        videoItems.forEach(video => observer.observe(video));
    }

    /**
     * Create ripple effect for interactive elements
     */
    function createRippleEffect(event, element) {
        const ripple = document.createElement('span');
        const rect = element.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = event.clientX - rect.left - size / 2;
        const y = event.clientY - rect.top - size / 2;

        ripple.style.cssText = `
            position: absolute;
            border-radius: 50%;
            background: rgba(0, 123, 255, 0.3);
            transform: scale(0);
            left: ${x}px;
            top: ${y}px;
            width: ${size}px;
            height: ${size}px;
            pointer-events: none;
            animation: ripple 0.6s ease-out;
        `;

        // Add ripple animation keyframes if not already present
        if (!document.querySelector('#ripple-styles')) {
            const style = document.createElement('style');
            style.id = 'ripple-styles';
            style.textContent = `
                @keyframes ripple {
                    to {
                        transform: scale(2);
                        opacity: 0;
                    }
                }
            `;
            document.head.appendChild(style);
        }

        element.style.position = 'relative';
        element.style.overflow = 'hidden';
        element.appendChild(ripple);

        setTimeout(() => {
            ripple.remove();
        }, 600);
    }

    /**
     * Announce messages to screen readers
     */
    function announceToScreenReader(message) {
        const announcement = document.createElement('div');
        announcement.setAttribute('aria-live', 'polite');
        announcement.setAttribute('aria-atomic', 'true');
        announcement.setAttribute('class', 'sr-only');
        announcement.style.cssText = `
            position: absolute;
            left: -10000px;
            width: 1px;
            height: 1px;
            overflow: hidden;
        `;
        
        document.body.appendChild(announcement);
        announcement.textContent = message;
        
        setTimeout(() => {
            document.body.removeChild(announcement);
        }, 1000);
    }

    /**
     * Handle contact form submission (if form is added in future)
     */
    function setupContactForm() {
        const contactForm = document.querySelector('#contact-form');
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Add form submission logic here
                const formData = new FormData(this);
                console.log('Form submitted:', Object.fromEntries(formData));
                
                // Show success message
                announceToScreenReader('Thank you for your message. I will get back to you soon!');
            });
        }
    }

    /**
     * Error handling for the application
     */
    function setupErrorHandling() {
        window.addEventListener('error', function(e) {
            console.error('Application error:', e.error);
            // Could implement user-friendly error reporting here
        });

        window.addEventListener('unhandledrejection', function(e) {
            console.error('Unhandled promise rejection:', e.reason);
        });
    }

    /**
     * Performance monitoring
     */
    function setupPerformanceMonitoring() {
        // Log page load performance
        window.addEventListener('load', function() {
            if ('performance' in window) {
                const navigation = performance.getEntriesByType('navigation')[0];
                console.log(`Page load time: ${navigation.loadEventEnd - navigation.loadEventStart}ms`);
            }
        });
    }

    // Initialize the application when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Setup additional features
    setupErrorHandling();
    setupPerformanceMonitoring();
    setupContactForm();

    // Expose useful functions for debugging
    window.portfolioApp = {
        announceToScreenReader,
        createRippleEffect
    };

})();
